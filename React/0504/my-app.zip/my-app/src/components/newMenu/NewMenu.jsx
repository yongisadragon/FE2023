import "./NewMenu.css";

function NewMenu() {
  return (
    <ul className="newClass">
      <li>마라탕</li>
      <li>차돌</li>
      <li>꿔바로우</li>
    </ul>
  );
}

export default NewMenu;
